<?php
/**
 * Code is poetry.
 */