<?php
/**
Plugin Name: Membership Support
Plugin URI:  https://premium.wpmudev.org/project/membership/
Version:     1.0.0-beta
Description: The most powerful, easy to use and flexible membership plugin for WordPress sites available.
Author:      WPMU DEV
Author URI:  http://premium.wpmudev.org/
WDP ID:      1003656
License:     GNU General Public License (Version 2 - GPLv2)
Text Domain: sz
*/

$x = __( 'Hello Mars Nice!', 'sz' );